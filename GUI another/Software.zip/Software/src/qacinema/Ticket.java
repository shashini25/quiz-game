/* 
*    AUTHOR : Maclyn Afonso
*/
package qacinema;

public interface Ticket
{
    public String TICKET_OFFSET="ID";
    
    public int TICKET_BOOKING_ID=1;
     public int Quantity=1;
    public int Date=17/11/2023;
    //Same method names with multiple argument lists ----EXAMPLE OF POLYMORPHISM
    public void setTicketTotal(int t);
    public void setTicketTotal(String t);
    public void setNumberOfTickets(int t); 
    public void setNumberOfTickets(String t);
    public int getTicketTotal();
    public int getNumberOfTickets();
    public String generateTicketID();
    public void updateTicketBookingId();    
}
