/* 
*    AUTHOR : Maclyn Afonso
*/
package qacinema;

import java.util.*;
import static qacinema.Ticket.Quantity;

public class Movie 
{
    
    private Map<String,Integer> map; //String : Movie Name and Integer : Number of Available Seats
    
    public Movie()
    {
         map=new HashMap<String,Integer>();
        map.put("Coca Cola",Quantity);  
        map.put("Pepsi",Quantity);  
        map.put("Fanta",Quantity); 
        map.put("Maza",Quantity); 
     System.out.println("Original Map::::");
		map.forEach((k,v)->System.out.println(k+"\t"+v));
		
        Set<Map.Entry<String, Integer>> entrySet = map.entrySet();
		
		List<Map.Entry<String, Integer>> list= new ArrayList<>(entrySet);
		
		Collections.sort(list, (o1, o2) -> o1.getValue().compareTo(o2.getValue()));
		
		System.out.println("Map sorted based on Quantities::");
		
		list.forEach(s->{
			System.out.println(s.getKey()+"\t"+s.getValue());
    });
    }             
    public Map<String,Integer> getMovieListings()
    {
        return this.map;
    }
    public int getNumberOfTicketsAvailable(String mname) 
    {
        for(Map.Entry m:map.entrySet())
        {  
            if(m.getKey().toString().equalsIgnoreCase(mname))
                return (int)m.getValue();  
        }  
        return 0;
    }
}
